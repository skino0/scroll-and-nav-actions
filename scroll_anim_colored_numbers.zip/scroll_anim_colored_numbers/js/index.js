var options = {
    animateThreshold: 100,
    scrollPollInterval: 0
}
$('.op').AniView(options);
$('.left').AniView(options);
$('.right').AniView(options);
$('.top').AniView(options);
$('.cloudup').AniView(options);
$('.cloudup2').AniView(options);
$('.open').AniView(options);
