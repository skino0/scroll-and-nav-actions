var options = {
    animateThreshold: 100,
    scrollPollInterval: 0
}
$('.op').AniView(options);
$('.left').AniView(options);
$('.right').AniView(options);
$('.top').AniView(options);



